#include <iostream>
#include <random>
using namespace std;

int get_random_number() {
	random_device seed; //Random seed
	uniform_int_distribution<int> distribution(0, 100);
	mt19937 gen(seed()); //Seed the endine
	int random_number = distribution(gen); //Generate from parameters given
	return random_number;
}

int lets_play(int goal) {
	cout << "Arvaa luku (1-100): ";
	int guess;
	cin >> guess;
	if (guess > goal) {
		cout << "Liian suuri!\n";
		return 1;
	}
	if (guess < goal) {
		cout << "Liian pieni\n";
		return 1;
	}
	else {
		return 0;
		}
}


int main() {
	int comnumber;
	int guesses;
	guesses = 1;
	comnumber = get_random_number();
	while (lets_play(comnumber)) {
		guesses += 1;
	}
	cout << "Oikein! Teit " << guesses << " arvausta." << endl;
}